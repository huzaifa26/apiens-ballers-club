import styles from "./Story.module.css";

function Story() {
    return ( 
        <div id="Story" className={styles.storyContainer}>
            <div className={styles.firstDiv}>
                <img className={styles.banner} src="https://themetakongz.com/_img/story_pster.png" alt=""/>
                <img className={styles.ape} src="https://themetakongz.com/_img/story_kongz_bg.jpg" alt=""/>
            </div>
            <div className={styles.secondDiv}>
                <img className={styles.sDImg} src="https://themetakongz.com/_img/story_konz_1.png" alt=""/>

                <div className={styles.story}>
                    <h1>STORY <span>The Apiens : Beginz</span></h1>
                    <div>
                        <h2><span>#1.</span> Every holiday, people gather at the circus.</h2>
                        <p>In a glass cage, they groom each other, but even that is starting to get frustrating. They look outside and see people giggling and having fun, but what’s so fun?</p>
                        <p>Then one day, a poster flew in front of a yawning gorilla. A paradise of gorillas was depicted in the poster.</p>
                        <p>(The Most Complete Ecosystem: The newly built Half Moon National Park)</p>
                    </div>
                    <br/>
                    <div>
                        <h2><span>#2.</span> Is there really such a place?</h2>
                        <p>Now gorillas don’t even care about their trainers’ passionate training anymore.</p>
                        <p>The image from the poster floats in their minds while they jump over burning rings and play instruments.</p>
                        <p>Speaking of which, who has this poster now?</p>
                        <p>The gorillas look at each other and notice that they are all empty-handed.</p>
                        <p>The trainer gives up and exits the room. As soon as he turns off the lights, the gorillas hear a ZAP!!</p>
                        <p>In the circus, a light begins to emit from the manhole below them.</p>
                    </div>
                    <br/>

                    <div>
                        <h2><span>#3.</span> Have you ever seen a gorilla in a robe with goggles?</h2>
                        <p>In a white lab below the circus, a gorilla wearing goggles is assembling a large engine.</p>
                        <p>Paused, the gorilla asks the visitors to sit down. He then walks towards a wall and opens the curtains.</p>
                        <p>Two shoddy drawings and a poster</p>
                        <p>The gorilla points to the text and tilts his head and says.</p>
                        <p>"Still don’t understand?"</p>
                        <p>The text reads: (To the Paradise/Craft and Fly)</p>
                    </div>
                    <br/>

                    <div>
                        <h2><span>#4.</span> Do we need sausages to elevate the circus? how about bananas?</h2>
                        <p>In the spiderweb-like sewers beneath the city, the gorillas go looking for parts instead of going home.</p>
                        <p>At the last jewerly store, the entered a room  filled with expensive watches. Now the gorillas understand the concept of time.</p>
                        <p>Sooner or later, rumors will start to circulate among people. People will begin to say, "Watch out for the gorilla’s hands in the sewer".</p>
                    </div>

                </div>
            </div>
        </div>
     );
}

export default Story;